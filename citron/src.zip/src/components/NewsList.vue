<template>
  <div class="sourceSelection">
    Sourceselection
  </div>
</template> 

<script>
export default {
  name: 'SourceSelection',
  data () {
    return {
      sources: [],
      source: ''
    }
  }
}
</script>

<style scoped>
</style>
