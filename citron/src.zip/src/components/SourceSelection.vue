<template>
  <div class="sourceSelection">
    <h1>the is second header</h1>
  </div>
</template> 

<script>
export default {
  name: 'SourceSelection',
  data () {
    return {
      sources: [],
      source: ''
    }
  }
}
</script>

<style scoped>
</style>
