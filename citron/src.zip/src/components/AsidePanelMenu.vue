<template>
 <div class="app__leftbar">
   <nav class="main__nav">
     <ul>
       <li class="active">
         <a href="">
          <span class="main__nav__icon"><i class="ion-speedometer"></i></span>
          Dashboard
        </a>
      </li>
      <li>
         <a href="">
          <span class="main__nav__icon"><i class="ion-clipboard"></i></span>
          Feeds
        </a>
      </li>
     </ul>
   </nav>
 </div>
</template> 

<script>
export default {
  name: 'AsidePanelMenu',
  data () {
    return {}
  }
}
</script>

<style scoped>

</style>
