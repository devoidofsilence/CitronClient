
<template>
  <section class="employees__list__row">
    <div class="row">
      <div class="col-xs-12 col-sm-6 col-md-4">
        <div class="box__card box__card--one">
          <div class="box__card__content">
            <div class="box__card__avatar">
              <div class="avatar__image">
                <figure>
                  <img src="../assets/images/user__avatar-1.jpg" class="img-circle user-img">
                </figure>
              </div>
            </div>
            <div class="box__card__text">adsfasdf </div>
          </div>
          <div class="box__card__footer"></div>
        </div>
      </div>
    </div>
  </section>
</template> 


<script>
export default {
  name: 'EmployeesList',
  data () {
    return {
      msg: 'Citron'
    }
  }
}
</script>

<style scoped>
.taskNull__content{
  text-align: center;
  width: 100%;
height: 100%;
}
.taskNull__content p{
  font-size: 26px;
  font-weight: 300;
}
.box__card{
  background-color: #fff;
  border-radius: 3px;
}
.box__card__content{
  padding: 15px;
}
.box__card__avatar{
  float: left;
  margin-right: 15px;
}
</style>
